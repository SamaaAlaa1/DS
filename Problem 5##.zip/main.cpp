#include"StatisticalCalculation.h"
#include"StatisticalCalculation.cpp"
int main() {
    StatisticalCalculation<int> arr;
    arr.statisticsMenu();

    return 0;
}